package com.techefx.microservices.productstockservice.techefxproductstockservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechefxProductStockServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechefxProductStockServiceApplication.class, args);
	}

}
