package com.techefx.microservices.productstockservice.techefxproductstockservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechefxProductStockServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
