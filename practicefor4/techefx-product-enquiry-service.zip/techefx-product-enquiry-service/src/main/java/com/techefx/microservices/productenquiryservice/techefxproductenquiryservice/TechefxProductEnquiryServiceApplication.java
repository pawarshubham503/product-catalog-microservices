package com.techefx.microservices.productenquiryservice.techefxproductenquiryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechefxProductEnquiryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechefxProductEnquiryServiceApplication.class, args);
	}

}
