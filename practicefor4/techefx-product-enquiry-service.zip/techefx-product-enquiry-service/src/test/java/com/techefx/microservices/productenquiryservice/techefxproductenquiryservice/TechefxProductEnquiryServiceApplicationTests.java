package com.techefx.microservices.productenquiryservice.techefxproductenquiryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechefxProductEnquiryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
