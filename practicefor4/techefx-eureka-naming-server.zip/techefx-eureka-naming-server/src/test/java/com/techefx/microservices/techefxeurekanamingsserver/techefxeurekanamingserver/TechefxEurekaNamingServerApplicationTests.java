package com.techefx.microservices.techefxeurekanamingsserver.techefxeurekanamingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechefxEurekaNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
