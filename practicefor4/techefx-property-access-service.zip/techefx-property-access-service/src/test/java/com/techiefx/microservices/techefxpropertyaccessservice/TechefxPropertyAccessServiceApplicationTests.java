package com.techiefx.microservices.techefxpropertyaccessservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechefxPropertyAccessServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
